# 회사 로고 — 재구성본

원본(저해상도 PNG)의 구성을 그대로 따라 벡터로 다시 그렸습니다: 둥근 사각 타일 + 같은 중심의 아치 2개 + 점.
좌표계는 64×64, 타일 라운드 15, 아치 스트로크 6.2(끝은 평평하게), 마크 중심은 (20, 45)입니다.

| 파일 | 용도 |
| --- | --- |
| `ubisam-logo.svg` | 기본 — 그라디언트 타일(#56ADF7 → #1D82E8) + 오프화이트 마크. 원본에 가장 가깝습니다 |
| `ubisam-logo-flat.svg` | 단색 타일(#2196F3) + 흰 마크. 작은 크기(16~24px)나 인쇄용 |
| `ubisam-logo-mono.svg` | 타일이 `currentColor` — 다크 배경에서 타일 색만 바꿔 쓸 때 |
| `ubisam-mark.svg` | 타일 없이 마크만, `currentColor`. 이미 파란 판 위에 얹을 때 |
| `../code/UbisamBase.Core/Themes/Logo.xaml` | WPF용 `DrawingImage` 리소스 (같은 도형) |

## WPF에서 쓰기

`ShellStyles.xaml`의 머지 목록에 `Logo.xaml`을 추가하고, `ShellWindow.xaml`의 로고 자리(accent 사각형 + 첫 글자)를 이미지로 교체하세요.

```xml
<Image Source="{StaticResource Ubisam.Logo}" Width="30" Height="30" VerticalAlignment="Center"/>
```

## 주의

- 원본이 저해상도라 라운드 반경·스트로크 두께·마크 여백은 눈으로 맞춘 근사값입니다. 원본 벡터(AI/SVG) 파일이 있으면 그걸 쓰는 게 정확합니다.
- 작은 크기에서는 그라디언트가 뭉개져 보이므로 `flat` 버전을 쓰세요.
- 타일 없이 흰 배경에 마크만 놓으면 대비가 부족합니다 — 마크만 쓸 때는 accent 색을 지정하세요.
